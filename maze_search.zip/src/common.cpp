/*
 * bfs.cpp
 *
 *  Created on: May 30, 2020
 *      Author: Neha
 */

#include "common.h"
#include "in.h"
#include "out.h"

int curRows = 5, curCols = 5;
tile *field = (tile *) malloc(sizeof(tile) * curRows * curCols);
tile *cur;
tile *mapCur;
int startR = 0, startC = 0;
tile *start;

void remap(int r, int c, Directions dir) {
	printf("\nREMAP\n");
	int add = 5;

	if (dir == N) {
		curRows += add;
		r += add;
		startR += add;
		tile *nfield = (tile *) malloc(sizeof(tile) * curRows * curCols);
		memset(nfield, 0, sizeof(tile) * curRows * curCols);
		memcpy(nfield + add * curCols, field, (curRows - add) * curCols);
		free(field);
		field = nfield;
	}

	else if (dir == E) {
		curCols += add;
		tile *nfield = (tile *) malloc(sizeof(tile) * curRows * curCols);
		memset(nfield, 0, sizeof(tile) * curRows * curCols);
		for (int i = 0; i < curRows; i++) {
			memcpy(nfield + (i * curCols), field + (i * (curCols - add)),
					curCols - add);
		}
		free(field);
		field = nfield;
	}

	else if (dir == S) {
		curRows += add;
		tile *nfield = (tile *) malloc(sizeof(tile) * curRows * curCols);
		memset(nfield, 0, sizeof(tile) * curRows * curCols);
		memcpy(nfield, field, (curRows - add) * curCols);
		free(field);
		field = nfield;
	}

	else if (dir == W) {
		curCols += add;
		c += add;
		startC += add;
		tile *nfield = (tile *) malloc(sizeof(tile) * curRows * curCols);
		memset(nfield, 0, sizeof(tile) * curRows * curCols);
		for (int i = 0; i < curRows; i++) {
			memcpy(nfield + (i * curCols) + add, field + (i * (curCols - add)),
					curCols - add);
		}
		free(field);
		field = nfield;
	}

	cur = field + c + (r * curCols);
	start = field + startC + (startR * curCols);
}

void simpleTraverse(tile *map, int nRows, int nCols) {
	Directions dir = N;
	int r;
	int c;
	for (int fails = 0; fails < 4;) {
		switch (dir) {
		case N: {
			if (cur->N == 0) {
				r = (cur - field) / curCols;
				c = (cur - field) % curCols;
				if (r == 0)
					remap(r, c, dir);
				if ((cur - curCols)->visited == 0) {
					fails = 0;
					mapCur -= nCols;
					cur -= curCols;
					printMap(map, nRows, nCols);
					readTile();
					break;
				}
			}
			fails++;
		}
		case E: {
			dir = E;
			if (cur->E == 0) {
				r = (cur - field) / curCols;
				c = (cur - field) % curCols;
				if (c == curCols - 1)
					remap(r, c, dir);
				if ((cur + 1)->visited == 0) {
					fails = 0;
					mapCur++;
					cur++;
					printMap(map, nRows, nCols);
					readTile();
					break;
				}
			}
			fails++;
		}
		case S: {
			dir = S;
			if (cur->S == 0) {
				r = (cur - field) / curCols;
				c = (cur - field) % curCols;
				if (r == curRows - 1)
					remap(r, c, dir);
				if ((cur + curCols)->visited == 0) {
					fails = 0;
					mapCur += nCols;
					cur += curCols;
					printMap(map, nRows, nCols);
					readTile();
					break;
				}
			}
			fails++;
		}
		case W: {
			dir = W;
			if (cur->W == 0) {
				r = (cur - field) / curCols;
				c = (cur - field) % curCols;
				if (c == 0)
					remap(r, c, dir);
				if ((cur - 1)->visited == 0) {
					fails = 0;
					mapCur--;
					cur--;
					printMap(map, nRows, nCols);
					readTile();
					break;
				}
			}
			fails++;
			dir = N;
		}
		}
	}
}

node* enq(node *wq, node* tailNode, int n) {
	node *newNode;
	newNode = (node*) malloc(sizeof(node));
	if (newNode == 0) {
		printf("\nerror\n");
		return 0;
	}

	memset(newNode, 0, sizeof(node));
	newNode->value = n;

	if (wq != 0) { //not empty list
		tailNode->next = newNode;
		newNode->prev = tailNode;
	}

	return newNode;
}

node* deq(node *wq) {
	if (wq->next == 0)
		return 0;
	node *headNode = wq->next;
	free(wq);
	headNode->prev = 0;
	return headNode;
}

bool bfs(tile *map, int nRows, int nCols) {
	node *wq = 0;
	node *tailNode = 0;

	int *pq = (int *) malloc(sizeof(int) * curRows * curCols);
	memset(pq, -1, sizeof(int) * curRows * curCols);

	tile* search = cur;
	wq = enq(wq, tailNode, search - field);
	tailNode = wq;

	pq[search - field] = search - field;

	Directions dir;
	bool doRemap = false;
	int r = (cur - field) / curCols;
	int c = (cur - field) % curCols;

	while (true) {
		if ((search)->N == 0) {
			if (r == 0) {
				dir = N;
				doRemap = true;
				break;
			} else if ((search - curCols)->visited == 0) {
				search -= curCols;
				break;
			} else if (pq[search - field - curCols] == -1) {
				tailNode = enq(wq, tailNode, search - field - curCols);
				pq[search - field - curCols] = wq->value;
			}
		}

		if ((search)->E == 0) {
			if (c == curCols - 1) {
				dir = E;
				doRemap = true;
				break;
			} else if ((search + 1)->visited == 0) {
				search += 1;
				break;
			} else if (pq[search - field + 1] == -1) {
				tailNode = enq(wq, tailNode, search - field + 1);
				pq[search - field + 1] = wq->value;
			}
		}

		if ((search)->S == 0) {
			if (r == curRows - 1) {
				dir = S;
				doRemap = true;
				break;
			} else if ((search + curCols)->visited == 0) {
				search += curCols;
				break;
			} else if (pq[search - field + curCols] == -1) {
				tailNode = enq(wq, tailNode, search - field + curCols);
				pq[search - field + curCols] = wq->value;
			}
		}

		if ((search)->W == 0) {
			if (c == 0) {
				dir = W;
				doRemap = true;
				break;
			} else if ((search - 1)->visited == 0) {
				search -= 1;
				break;
			} else if (pq[search - field - 1] == -1) {
				tailNode = enq(wq, tailNode, search - field - 1);
				pq[search - field - 1] = wq->value;
			}
		}

		wq = deq(wq);
		if (wq == 0)
			return 0;

		search = field + wq->value;
		r = (search - field) / curCols;
		c = (search - field) % curCols;
	}
	if (doRemap == false)
		pq[search - field] = wq->value;

//create path
	int *path = (int *) malloc((sizeof(int)) * curRows * curCols);
	memset(path, -1, sizeof(int) * curRows * curCols);
	*path = search - field;
	while (*path != (cur - field)) {
		path++;
		*path = pq[*(path - 1)];
	}
	path--;

//follow path
	while (*path != search - field) {
		if (cur - ((*path) + field) == curCols)
			mapCur -= nCols;
		else if (cur - ((*path) + field) == (-1 * curCols))
			mapCur += nCols;
		else if (cur - ((*path) + field) == 1)
			mapCur--;
		else if (cur - ((*path) + field) == -1)
			mapCur++;
		cur -= cur - ((*path) + field);
		printMap(map, nRows, nCols);
		path--;
	}
	if (cur - search == curCols)
		mapCur -= nCols;
	else if (cur - search == (-1 * curCols))
		mapCur += nCols;
	else if (cur - search == 1)
		mapCur--;
	else if (cur - search == -1)
		mapCur++;
	cur = search;
	readTile();
	printMap(map, nRows, nCols);

	if (doRemap == true) {
		r = (cur - field) / curCols;
		c = (cur - field) % curCols;
		remap(r, c, dir);
		if (dir == N) {
			mapCur -= nCols;
			cur -= curCols;
		} else if (dir == E) {
			mapCur++;
			cur++;
		} else if (dir == S) {
			mapCur += nCols;
			cur += curCols;
		} else if (dir == W) {
			mapCur--;
			cur--;
		}
		readTile();
		printMap(map, nRows, nCols);
	}

	return 1;
}

void toStart(tile *map, int nRows, int nCols) {
	node *wq = 0;
	node *tailNode = 0;

	int *pq = (int *) malloc(sizeof(int) * curRows * curCols);
	memset(pq, -1, sizeof(int) * curRows * curCols);

	tile* search = cur;
	wq = enq(wq, tailNode, search - field);
	tailNode = wq;

	pq[search - field] = search - field;

	bool doRemap = false;

	while (true) {
		if ((search)->N == 0) {
			if ((search - curCols) == start) {
				search -= curCols;
				break;
			} else if (pq[search - field - curCols] == -1) {
				tailNode = enq(wq, tailNode, search - field - curCols);
				pq[search - field - curCols] = wq->value;
			}
		}

		if ((search)->E == 0) {
			if ((search + 1) == start) {
				search += 1;
				break;
			} else if (pq[search - field + 1] == -1) {
				tailNode = enq(wq, tailNode, search - field + 1);
				pq[search - field + 1] = wq->value;
			}
		}

		if ((search)->S == 0) {
			if ((search + curCols) == start) {
				search += curCols;
				break;
			} else if (pq[search - field + curCols] == -1) {
				tailNode = enq(wq, tailNode, search - field + curCols);
				pq[search - field + curCols] = wq->value;
			}
		}

		if ((search)->W == 0) {
			if ((search - 1) == start) {
				search -= 1;
				break;
			} else if (pq[search - field - 1] == -1) {
				tailNode = enq(wq, tailNode, search - field - 1);
				pq[search - field - 1] = wq->value;
			}
		}

		wq = deq(wq);

		search = field + wq->value;
	}
	if (doRemap == false)
		pq[search - field] = wq->value;

	//create path
	int *path = (int *) malloc((sizeof(int)) * curRows * curCols);
	memset(path, -1, sizeof(int) * curRows * curCols);
	*path = search - field;
	while (*path != (cur - field)) {
		path++;
		*path = pq[*(path - 1)];
	}
	path--;

	//follow path
	while (*path != search - field) {
		if (cur - ((*path) + field) == curCols)
			mapCur -= nCols;
		else if (cur - ((*path) + field) == (-1 * curCols))
			mapCur += nCols;
		else if (cur - ((*path) + field) == 1)
			mapCur--;
		else if (cur - ((*path) + field) == -1)
			mapCur++;
		cur -= cur - ((*path) + field);
		printMap(map, nRows, nCols);
		path--;
	}

	if (cur - search == curCols)
		mapCur -= nCols;
	else if (cur - search == (-1 * curCols))
		mapCur += nCols;
	else if (cur - search == 1)
		mapCur--;
	else if (cur - search == -1)
		mapCur++;
	cur = search;
	printMap(map, nRows, nCols);
}
