/*
 * bfs.h
 *
 *  Created on: May 30, 2020
 *      Author: Neha
 */

#ifndef COMMON_H_
#define COMMON_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif

#ifdef _WIN32
#define sleep(x) Sleep(x);
#else
#define sleep(x) sleep(x);
#endif

typedef unsigned char ubyte;
struct tile {
	ubyte N :1;
	ubyte E :1;
	ubyte S :1;
	ubyte W :1;
	ubyte visited :1;
};

enum Directions {
	N, E, S, W
};

struct node {
	struct node* prev;
	int value;
	struct node* next;
};

extern int curRows, curCols;
extern tile *field;
extern tile *cur;
extern tile *mapCur;
extern int startR, startC;
extern tile *start;

void remap(int r, int c, Directions dir);
void simpleTraverse(tile *map, int nRows, int nCols);
node* enq(node *wq, node* tailNode, int n);
node* deq(node *wq);
bool bfs(tile *map, int nRows, int nCols);
void toStart(tile *map, int nRows, int nCols);

#endif /* COMMON_H_ */
