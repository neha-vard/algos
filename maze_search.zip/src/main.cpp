//============================================================================
// Name        : bfs.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include "main.h"
#include "common.h"
#include "in.h"
#include "out.h"

int main() {

	//generates map for user
	int nRows, nCols;
	getDim(&nRows, &nCols);
	tile *map = (tile *) malloc(sizeof(tile) * nRows * nCols);
	memset(map, 0, sizeof(tile) * nRows * nCols);
	mapCur = map;
	getMap(map, nRows, nCols);
	printMap(map, nRows, nCols);

	startR = 0;
	startC = 0;
	memset(field, 0, sizeof(tile) * curRows * curCols);
	cur = field;
	start = field;
	readTile();

	tile* prevCur;
	do {
		printf("\nvisited\n");
		printVisited(map, nRows, nCols);

		prevCur = cur;
		printf("\nsimple traverse\n");
		simpleTraverse(map, nRows, nCols);

		if (cur != prevCur) {
		printf("\nvisited\n");
		printVisited(map, nRows, nCols);
		}

		printf("\n\nbfs\n");
	} while (bfs(map, nRows, nCols));

	printf("\nreturn to start\n");

	toStart(map, nRows, nCols);

	printf("\nend of program\n");

	return 0;
}

