/*
 * in.cpp
 *
 *  Created on: May 30, 2020
 *      Author: Neha
 */

#include "in.h"

void getDim(int *nRows, int *nCols) {
	FILE *fp;
	fp = fopen(FILE_NAME, "r+");
	if (fp == NULL) {
		exit(EXIT_FAILURE);
	}
	fscanf(fp, "%d %d", nRows, nCols);
	fclose(fp);
}

void getMap(tile *map, int nRows, int nCols) {
	FILE *fp;
	fp = fopen(FILE_NAME, "r+");
	if (fp == NULL) {
		exit(EXIT_FAILURE);
	}

	//nRows and nCols
	int x, y;
	fscanf(fp, "%d %d", &x, &y);
	fgetc(fp);

	//first row
	fgetc(fp);
	for (int i = 0; i < nCols; i++) {
		for (int j = 0; j < 3; j++) {
			if (fgetc(fp) == '_')
				(map + i)->N = 1;
		}
		fgetc(fp);
	}

	for (int i = 0; i < nRows * nCols; i++) {
		//west
		if (fgetc(fp) == '|') {
			(map + i)->W = 1;
			if (i % nCols != 0)
				(map + i - 1)->E = 1;
		}
		//north and south
		char bit;
		for (int j = 0; j < 3; j++) {
			if ((bit = fgetc(fp)) == '_') {
				(map + i)->S = 1;
				if (i / nCols != nRows - 1)
					(map + i + nCols)->N = 1;
			}
			else if (bit == 'x') mapCur = map + i;
		}
		//east
		if (i % nCols == nCols - 1) {
			if (fgetc(fp) == '|')
				(map + i)->E = 1;
			fgetc(fp);
		}
	}
}

void readTile() {
	memcpy(cur, mapCur, sizeof(tile));
	cur->visited = 1;
	mapCur->visited = 1;
}

