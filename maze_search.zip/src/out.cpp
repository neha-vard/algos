/*
 * out.cpp
 *
 *  Created on: May 30, 2020
 *      Author: Neha
 */
#include "common.h"
#include "out.h"

void printMap(tile *map, int nRows, int nCols) {
	getchar();
	clear();
	int index = mapCur - map;

	for (int i = 0; i < nCols; i++) {
		if ((map + i)->N == 1)
			printf(" ___");
	}
	printf("\n");
	for (int i = 0; i < nRows * nCols; i++) {
		//west
		if ((map + i)->W == 1)
			printf("|");
		else
			printf(",");
		//north and south
		if ((map + i)->S == 1) {
			if (i == index)
				printf("_x_");
			else
				printf("___");
		} else {
			if (i == index)
				printf(".x.");
			else
				printf("...");
		}
		//east
		if (i % nCols == nCols - 1) {
			if ((map + i)->E == 1) {
				printf("|");
			} else
				printf(",");
			printf("\n");
		}
	}
}

void printVisited2() {
	for (int i = 0; i < curRows * curCols; i++) {
		if (i % curCols == 0)
			printf("\n");
		if ((field + i)->visited == 1)
			printf("%-4d ", i);
		else
			printf("     ");
	}
}

void printVisited(tile *map, int nRows, int nCols) {
	for (int i = 0; i < nCols; i++) {
		if ((map + i)->N == 1)
			printf(" ___");
	}
	printf("\n");
	for (int i = 0; i < nRows * nCols; i++) {
		//west
		if ((map + i)->W == 1)
			printf("|");
		else
			printf(",");
		//north and south
		if ((map + i)->S == 1) {
			if ((map + i)->visited == 1)
				printf("_x_");
			else
				printf("___");
		} else {
			if ((map + i)->visited == 1)
				printf(".x.");
			else
				printf("...");
		}
		//east
		if (i % nCols == nCols - 1) {
			if ((map + i)->E == 1) {
				printf("|");
			} else
				printf(",");
			printf("\n");
		}
	}
}
